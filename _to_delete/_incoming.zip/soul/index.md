# Soul System Index

Read this first. It tells you where everything lives.

## Wiki (Core Knowledge)

| File | What's in it |
|------|-------------|
| [wiki/01-identity-and-positioning.md](wiki/01-identity-and-positioning.md) | Who Dr. Renee is, origin story, positioning, mission, credentials |
| [wiki/02-brand-voice.md](wiki/02-brand-voice.md) | Voice rules, banned phrases, writing standards, content quality tests |
| [wiki/03-ideal-client.md](wiki/03-ideal-client.md) | Ideal client avatar, buyer personas, pain points, triggering events |
| [wiki/04-programs-and-offers.md](wiki/04-programs-and-offers.md) | All offers, pricing, engagement tiers, the REST ecosystem |
| [wiki/05-market-and-competitors.md](wiki/05-market-and-competitors.md) | Market landscape, positioning against alternatives, ROI story |
| [wiki/company-details.md](wiki/company-details.md) | Business logistics, entities, websites, tools, current stage |
| [wiki/dreams.md](wiki/dreams.md) | Big vision, revenue goals, what she's building toward |
| [wiki/best-content.md](wiki/best-content.md) | Examples of great content with why it worked |
| [wiki/glossary.md](wiki/glossary.md) | REST terms, coined phrases, and definitions |

## Content & Stories

| Folder | What's in it |
|--------|-------------|
| [my-content/](my-content/) | Published and in-progress content |
| [stories/](stories/) | Real moments from her life, tagged for reuse |
| [frameworks/](frameworks/) | The REST Framework and methodologies |
| [program-materials/](program-materials/) | Program content, curriculum, and assets |
| [presentations/](presentations/) | Talks, keynotes, and slide decks |
| [wins/](wins/) | Captured wins by date |
| [decisions/](decisions/) | Decisions made with context |
| [clients/](clients/) | Per-client files (optional) |

## Sources (Raw Clips)

| Folder | What's in it |
|--------|-------------|
| [sources/](sources/) | Raw web clips, articles, URLs saved for ingestion |

---
*Updated by Claude after each ingest. Add new wiki pages to the table above.*
